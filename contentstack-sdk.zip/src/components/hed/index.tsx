import React from 'react'

const Hedpage = () => {
  return (
    <div className='w-full fixed z-50 h-20 bg-red-500 sm:bg-black md:bg-green-500 lg:bg-amber-500 xl:bg-purple-600 2xl:bg-red-400 '>
        adadsada
    </div>
  )
}

export default Hedpage